package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.*;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.udacity.nanodegree.meysamabl.popularmovies.model.MovieParcelable;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.JsonUtils;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int GRID_NUMBER_OF_COLUMNS = 2;
    static final String MOVIE_PARCEL = "movieParcel";
    private static final String SORT_BY_POPULAR_MOVIES = "popular";
    private static final String SORT_BY_TOP_RATED_MOVIES = "top_rated";
    private MovieRecyclerViewAdapter mAdapter;
    @BindView(R.id.pb_loading_indicator)
    ProgressBar mProgressBar;
    @BindView(R.id.movie_recycle_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.error_message)
    TextView mErrorMessageTextView;
    @BindView(R.id.sort_by_drop_down_list)
    Spinner mSortBySpinner;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, GRID_NUMBER_OF_COLUMNS);
        mAdapter = new MovieRecyclerViewAdapter(this);

        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        ArrayAdapter<CharSequence> mSortByAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.sort_by,
                android.R.layout.simple_spinner_item
        );
        // Specify the layout to use when the list of choices appears
        mSortByAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // Apply the adapter to the spinner
        mSortBySpinner.setAdapter(mSortByAdapter);
        mSortBySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String itemSelected = adapterView.getSelectedItem().toString();
                if (itemSelected.equals(getString(R.string.sort_popular))) {
                    new MovieDBAsyncTask().execute(SORT_BY_POPULAR_MOVIES);
                } else if (itemSelected.equals(getString(R.string.sort_top_rated))) {
                    new MovieDBAsyncTask().execute(SORT_BY_TOP_RATED_MOVIES);
                }
            }

            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    class MovieDBAsyncTask extends AsyncTask<String, Void, List<MovieParcelable>> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            mProgressBar.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.INVISIBLE);
            mErrorMessageTextView.setVisibility(View.INVISIBLE);
        }

        @Override
        protected List<MovieParcelable> doInBackground(String... types) {
            if (types.length == 0) {
                return null;
            }
            try {
                String sortBy = types[0];
                String response = null;
                if (sortBy.equals(SORT_BY_TOP_RATED_MOVIES)) {
                    response = NetworkUtils.getMovieDbResponse(
                            MainActivity.this,
                            SORT_BY_TOP_RATED_MOVIES,
                            String.valueOf(1)
                    );
                } else if (sortBy.equals(SORT_BY_POPULAR_MOVIES)) {
                    response = NetworkUtils.getMovieDbResponse(
                            MainActivity.this,
                            SORT_BY_POPULAR_MOVIES,
                            String.valueOf(1)
                    );
                }
                if (response != null) {
                    mProgressBar.setVisibility(View.INVISIBLE);
                    mErrorMessageTextView.setVisibility(View.INVISIBLE);
                    return JsonUtils.getListOfMoviesFromJsonResponse(response);
                } else {
                    mProgressBar.setVisibility(View.INVISIBLE);
                    mErrorMessageTextView.setVisibility(View.VISIBLE);
                    mRecyclerView.setVisibility(View.INVISIBLE);
                    return null;
                }
            } catch (Exception ex) {
                return null;
            }
        }

        @Override
        protected void onPostExecute(List<MovieParcelable> movies) {
            if (movies != null) {
                mAdapter.setMovies(movies);
                mRecyclerView.setVisibility(View.VISIBLE);
            }
        }
    }
}
