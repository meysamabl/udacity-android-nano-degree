package com.udacity.nanodegree.meysamabl.popularmovies.utilities;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;
import com.udacity.nanodegree.meysamabl.popularmovies.BuildConfig;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NetworkUtils {

    private static final String TAG = NetworkUtils.class.getSimpleName();
    private static final String BASE_IMAGE_URL = "http://image.tmdb.org/t/p/";
    private static final String MOVIE_DB_BASE_URL = "http://api.themoviedb.org/3/movie";
    private static final String DEFAULT_IMAGE_SIZE = "w185";
    private static final String PAGE_QUERY = "page";
    private static final String API_KEY_QUERY = "api_key";
    private static final String YOUTUBE_URL = "http://www.youtube.com/watch?v=";
    private static final String YOU_TUBE_MIME = "vnd.youtube:";

    public static void loadImage(Context context, String filaPath, ImageView imageView) {
        String imageUrl = BASE_IMAGE_URL + DEFAULT_IMAGE_SIZE + filaPath;
        Picasso.with(context).load(imageUrl).into(imageView);
    }

    public static Bitmap getImage(Context context, String filaPath) throws IOException {
        String imageUrl = BASE_IMAGE_URL + DEFAULT_IMAGE_SIZE + filaPath;
        return Picasso.with(context).load(imageUrl).get();
    }

    private static URL buildMovieDBUrl(String sortType, String pageNumber) {
        String apiKey = BuildConfig.MOVIE_DB_API_KEY;
        Uri.Builder builtUri = Uri.parse(MOVIE_DB_BASE_URL).buildUpon()
                .appendPath(sortType)
                .appendQueryParameter(API_KEY_QUERY, apiKey);
        if (pageNumber != null) {
            builtUri = builtUri.appendQueryParameter(PAGE_QUERY, pageNumber);
        }
        Uri uri = builtUri.build();
        URL url = null;
        try {
            url = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.v(TAG, "Built URI " + url);
        return url;
    }

    /**
     * This method returns the entire result from the HTTP response.
     *
     * @return The contents of the HTTP response.
     * @throws IOException Related to network and stream reading
     */
    public static String getMovieDbResponse(Context context, String sortType, String pageNumber)
            throws IOException {
        if (isOnline(context)) {
            URL url = buildMovieDBUrl(sortType, pageNumber);
            return getHttpResponse(url);
        } else {
            return null;
        }
    }

    public static String getAssetsOfMovie(Context context, String assetType, String movieId) {
        if (isOnline(context)) {
            URL url = buildMovieAssetUrl(assetType, movieId);
            try {
                return getHttpResponse(url);
            } catch (IOException e) {
                e.printStackTrace();
                return null;
            }
        } else {
            return null;
        }
    }

    private static URL buildMovieAssetUrl(String assetType, String movieId) {
        String apiKey = BuildConfig.MOVIE_DB_API_KEY;
        Uri uri = Uri.parse(MOVIE_DB_BASE_URL).buildUpon()
                .appendPath(movieId)
                .appendPath(assetType)
                .appendQueryParameter(API_KEY_QUERY, apiKey).build();
        URL url = null;
        try {
            url = new URL(uri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.v(TAG, "Built URI " + url);
        return url;
    }

    private static String getHttpResponse(URL url) throws IOException {
        HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }

    private static boolean isOnline(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm != null ? cm.getActiveNetworkInfo() : null;
        return netInfo != null && netInfo.isConnected();
    }

    public static void watchYoutubeVideo(Context context, String id){
        Intent appIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(YOU_TUBE_MIME + id));
        Intent webIntent = new Intent(Intent.ACTION_VIEW,
                Uri.parse(YOUTUBE_URL + id));
        try {
            context.startActivity(appIntent);
        } catch (ActivityNotFoundException ex) {
            if (webIntent.resolveActivity(context.getPackageManager()) != null) {
                context.startActivity(webIntent);
            }
        }
    }
}
