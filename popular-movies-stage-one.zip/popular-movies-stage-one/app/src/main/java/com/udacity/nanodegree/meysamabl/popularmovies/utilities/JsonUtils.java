package com.udacity.nanodegree.meysamabl.popularmovies.utilities;

import com.udacity.nanodegree.meysamabl.popularmovies.model.MovieParcelable;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static List<MovieParcelable> getListOfMoviesFromJsonResponse(String jsonResponse) {
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            return getMovieListFromJson(jsonObject.getString("results"));
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static MovieParcelable convertJsonToMovie(JSONObject movieObject) throws JSONException {
        int id = movieObject.getInt("id");
        String title = movieObject.optString("original_title", "Title not provided");
        String posterPath = movieObject.optString("poster_path", null);
        String overview = movieObject.optString("overview", "Plot synopsis not provided");
        double voteAverage = movieObject.optDouble("vote_average", 0.0);
        String releaseDate = movieObject.optString("release_date", "Release Date not provided");
        return new MovieParcelable(id, title, posterPath, overview, voteAverage, releaseDate);
    }

    private static List<MovieParcelable> getMovieListFromJson(String jsonMovieList) throws JSONException {
        JSONArray movieArray = new JSONArray(jsonMovieList);
        List<MovieParcelable> movies = new ArrayList<>();
        MovieParcelable model;
        for (int i = 0; i < movieArray.length(); i++) {
            model = convertJsonToMovie(movieArray.getJSONObject(i));
            movies.add(model);
        }
        return movies;
    }
}
