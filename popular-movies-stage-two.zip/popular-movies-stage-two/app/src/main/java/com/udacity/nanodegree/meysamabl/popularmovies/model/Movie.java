package com.udacity.nanodegree.meysamabl.popularmovies.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.List;

public class Movie implements Parcelable {

    private int mId;
    private String mTitle;
    private String mImageUrl;
    private String mOverview;
    private double mVoteAverage;
    private String mReleaseDate;
    private String mLength;

    public Movie(int id, String title, String imageUrl,
                 String overview, double voteAverage, String mReleaseDate) {
        this.mId = id;
        this.mTitle = title;
        this.mImageUrl = imageUrl;
        this.mOverview = overview;
        this.mVoteAverage = voteAverage;
        this.mReleaseDate = mReleaseDate;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmOverview() {
        return mOverview;
    }

    public double getmVoteAverage() {
        return mVoteAverage;
    }

    public String getmReleaseDate() {
        return mReleaseDate;
    }

    public int getmId() {
        return mId;
    }

    public String getmLength() {
        return mLength;
    }

    public void setmLength(String mLength) {
        this.mLength = mLength;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.mId);
        dest.writeString(this.mTitle);
        dest.writeString(this.mImageUrl);
        dest.writeString(this.mOverview);
        dest.writeDouble(this.mVoteAverage);
        dest.writeString(this.mReleaseDate);
        dest.writeString(this.mLength);
    }

    protected Movie(Parcel in) {
        this.mId = in.readInt();
        this.mTitle = in.readString();
        this.mImageUrl = in.readString();
        this.mOverview = in.readString();
        this.mVoteAverage = in.readDouble();
        this.mReleaseDate = in.readString();
        this.mLength = in.readString();
    }

    public static final Parcelable.Creator<Movie> CREATOR = new Parcelable.Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
