package com.udacity.nanodegree.meysamabl.popularmovies.utilities;

import com.udacity.nanodegree.meysamabl.popularmovies.model.Movie;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Review;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Video;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static List<Movie> getListOfMoviesFromJsonResponse(String jsonResponse) {
        try {
            JSONObject jsonObject = new JSONObject(jsonResponse);
            return getMovieListFromJson(jsonObject.getString("results"));
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static Movie convertJsonToMovie(JSONObject movieObject) throws JSONException {
        int id = movieObject.getInt("id");
        String title = movieObject.optString("original_title", "Title not provided");
        String posterPath = movieObject.optString("poster_path", null);
        String overview = movieObject.optString("overview", "Plot synopsis not provided");
        double voteAverage = movieObject.optDouble("vote_average", 0.0);
        String releaseDate = movieObject.optString("release_date", "Release Date not provided");
        return new Movie(id, title, posterPath, overview, voteAverage, releaseDate);
    }

    public static Movie convertJsonToMovie(String json) throws JSONException {
        JSONObject movieObject = new JSONObject(json);
        int id = movieObject.getInt("id");
        String title = movieObject.optString("original_title", "Title not provided");
        String posterPath = movieObject.optString("poster_path", null);
        String overview = movieObject.optString("overview", "Plot synopsis not provided");
        double voteAverage = movieObject.optDouble("vote_average", 0.0);
        String releaseDate = movieObject.optString("release_date", "Release Date not provided");
        Movie movie = new Movie(id, title, posterPath, overview, voteAverage, releaseDate);
        int runtime = movieObject.optInt("runtime", -1);
        if (runtime > 0) {
            movie.setmLength(String.valueOf(runtime));
        }
        return movie;
    }

    private static List<Movie> getMovieListFromJson(String jsonMovieList) throws JSONException {
        JSONArray movieArray = new JSONArray(jsonMovieList);
        List<Movie> movies = new ArrayList<>();
        Movie model;
        for (int i = 0; i < movieArray.length(); i++) {
            model = convertJsonToMovie(movieArray.getJSONObject(i));
            movies.add(model);
        }
        return movies;
    }

    public static List<Review> getReviewListFromJson(String jsonReview) throws JSONException {
        JSONObject reviewObj = new JSONObject(jsonReview);
        JSONArray reviewArray = new JSONArray(reviewObj.getString("results"));
        List<Review> reviews = new ArrayList<>();
        Review model;
        for (int i = 0; i < reviewArray.length(); i++) {
            model = convertJsonToReview(reviewArray.getJSONObject(i));
            reviews.add(model);
        }
        return reviews;
    }

    private static Review convertJsonToReview(JSONObject object) throws JSONException {
        String id = object.getString("id");
        String author = object.optString("author", "Not Provided");
        String content = object.optString("content", null);
        String url = object.optString("url", null);
        return new Review(id, author, content, url);

    }

    private static Video convertJsonToVideo(JSONObject object) throws JSONException {
        String id = object.getString("id");
        String name = object.optString("name", "Not Provided");
        String key = object.optString("key", null);
        return new Video(id, name, key);

    }

    public static List<Video> getVideoListFromJson(String json) throws JSONException {
        JSONObject videoObj = new JSONObject(json);
        JSONArray movieArray = new JSONArray(videoObj.getString("results"));
        List<Video> videos = new ArrayList<>();
        Video video;
        for (int i = 0; i < movieArray.length(); i++) {
            video = convertJsonToVideo(movieArray.getJSONObject(i));
            videos.add(video);
        }
        return videos;
    }
}
