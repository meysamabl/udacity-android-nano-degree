package com.udacity.nanodegree.meysamabl.popularmovies.utilities;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.util.Log;
import android.widget.ImageView;
import com.squareup.picasso.Picasso;
import com.udacity.nanodegree.meysamabl.popularmovies.BuildConfig;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class NetworkUtils {

    private static final String TAG = NetworkUtils.class.getSimpleName();
    private static final String BASE_IMAGE_URL = "http://image.tmdb.org/t/p/";
    private static final String MOVIE_DB_BASE_URL = "http://api.themoviedb.org/3/movie";
    private static final String DEFAULT_IMAGE_SIZE = "w185";
    private static final String PAGE_QUERY = "page";
    private static final String API_KEY_QUERY = "api_key";

    public static void loadImage(Context context, String filaPath, ImageView imageView) {
        String imageUrl = BASE_IMAGE_URL + DEFAULT_IMAGE_SIZE + filaPath;
        Picasso.with(context).load(imageUrl).into(imageView);
    }

    private static URL buildMovieDBUrl(String sortType, String pageNumber) {
        String apiKey = BuildConfig.MOVIE_DB_API_KEY;
        Uri builtUri = Uri.parse(MOVIE_DB_BASE_URL).buildUpon()
                .appendPath(sortType)
                .appendQueryParameter(API_KEY_QUERY, apiKey)
                .appendQueryParameter(PAGE_QUERY, pageNumber)
                .build();

        URL url = null;
        try {
            url = new URL(builtUri.toString());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        Log.v(TAG, "Built URI " + url);
        return url;
    }

    /**
     * This method returns the entire result from the HTTP response.
     *
     * @return The contents of the HTTP response.
     * @throws IOException Related to network and stream reading
     */
    public static String getMovieDbResponse(Context context, String sortType, String pageNumber)
            throws IOException {
        if (isOnline(context)) {
            URL url = buildMovieDBUrl(sortType, pageNumber);
            HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
            try {
                InputStream in = urlConnection.getInputStream();

                Scanner scanner = new Scanner(in);
                scanner.useDelimiter("\\A");

                boolean hasInput = scanner.hasNext();
                if (hasInput) {
                    return scanner.next();
                } else {
                    return null;
                }
            } finally {
                urlConnection.disconnect();
            }
        } else {
            return null;
        }
    }

    private static boolean isOnline(Context context) {
        ConnectivityManager cm =
                (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        return netInfo != null && netInfo.isConnected();
    }
}
