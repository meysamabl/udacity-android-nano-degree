package com.udacity.nanodegree.meysamabl.popularmovies.db;

import android.net.Uri;
import android.provider.BaseColumns;

public final class MovieContract {

    private MovieContract() {
    }

    public static final String CONTENT_AUTHORITY = "com.udacity.nanodegree.meysamabl.popularmovies";
    public static final String FAVORITE_PATH = "favorites";
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + CONTENT_AUTHORITY);

    public static class MovieEntry implements BaseColumns {
        public static final Uri CONTENT_URI = BASE_CONTENT_URI.buildUpon().appendPath(FAVORITE_PATH).build();
        public static final String MOVIE_TABLE_NAME = "movies";
        public static final String COLUMN_MOVIE_TITLE = "title";
        public static final String COLUMN_MOVIE_POSTER = "poster";
        public static final String COLUMN_MOVIE_OVERVIEW = "overview";
        public static final String COLUMN_MOVIE_VOTE_AVERAGE = "ratings";
        public static final String COLUMN_MOVIE_RELEASE_DATE = "release_date";
        public static final String COLUMN_MOVIE_LENGTH = "length";
    }

}
