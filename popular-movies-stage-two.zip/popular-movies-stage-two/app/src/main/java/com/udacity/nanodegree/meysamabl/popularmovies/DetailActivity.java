package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.like.LikeButton;
import com.like.OnLikeListener;
import com.squareup.picasso.Picasso;
import com.udacity.nanodegree.meysamabl.popularmovies.db.MovieContract;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Movie;
import com.udacity.nanodegree.meysamabl.popularmovies.model.MovieAsset;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Review;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Video;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.JsonUtils;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class DetailActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String[]> {

    static final String MOVIE_ITEM = "movie_item";
    private final static String REQUEST_TYPE = "request_type";
    private final static String FETCH_TRAILERS = "videos";
    private final static String FETCH_REVIEWS = "reviews";
    private final static String ASSETS = "assets";
    @BindView(R.id.movie_image)
    ImageView movieThumbnailImageView;
    @BindView(R.id.title_tv)
    TextView movieTitleTextView;
    @BindView(R.id.overview_tv)
    TextView overviewTextView;
    @BindView(R.id.ratings_tv)
    TextView userRatingsTextView;
    @BindView(R.id.year_tv)
    TextView releaseDateTextView;
    @BindView(R.id.movie_length_tv)
    TextView lengthTextView;
    @BindView(R.id.details_recycleview)
    RecyclerView detailRecycleView;
    @BindView(R.id.fav_button)
    LikeButton likeButton;
    @BindView(R.id.show_trailer_btn)
    Button mShowTrailersButton;
    @BindView(R.id.show_reviews_btn)
    Button mShowReviewsButton;
    @BindView(R.id.trailers_label)
    TextView mAssetLabel;
    private static final int LOADER_CALLBACK_ID = 25;
    private Movie mModel;
    private Uri mUri;
    private String mFetchType;
    private DetailAssetRecycleViewAdapter assetAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ButterKnife.bind(this);
        Intent intent = getIntent();
        final ContentResolver resolver = getContentResolver();
        if (intent.hasExtra(MOVIE_ITEM)) {
            int modelId = intent.getIntExtra(MOVIE_ITEM, -1);
            Bundle bundle = new Bundle();
            bundle.putString(MOVIE_ITEM, String.valueOf(modelId));
            mUri = MovieContract.MovieEntry.CONTENT_URI.buildUpon().appendPath(String.valueOf(modelId)).build();
            Cursor cursor = resolver.query(mUri, null, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                mModel = new Movie(
                        cursor.getInt(cursor.getColumnIndex(MovieContract.MovieEntry._ID)),
                        cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_TITLE)),
                        cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_POSTER)),
                        cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_OVERVIEW)),
                        cursor.getDouble(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_VOTE_AVERAGE)),
                        cursor.getString(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_RELEASE_DATE))
                );
                mModel.setmLength(String.valueOf(cursor.getInt(cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_LENGTH))));
                populateUI(mModel);
                likeButton.setLiked(true);
                cursor.close();
            } else {
                mFetchType = null;
                getSupportLoaderManager().initLoader(LOADER_CALLBACK_ID, bundle, this).forceLoad();
            }
        }

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        assetAdapter = new DetailAssetRecycleViewAdapter();
        detailRecycleView.setLayoutManager(layoutManager);
        detailRecycleView.setHasFixedSize(true);
        detailRecycleView.setAdapter(assetAdapter);

        if (savedInstanceState != null) {
            int type = savedInstanceState.getInt(REQUEST_TYPE);
            List<MovieAsset> assetList = savedInstanceState.getParcelableArrayList(ASSETS);
            assetAdapter.swapMovieAsset(assetList, type);
        }

        mShowTrailersButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAssetLabel.setVisibility(View.VISIBLE);
                mAssetLabel.setText(getString(R.string.trailers));
                Log.v(DetailActivity.class.getSimpleName(), "TYPE: " + assetAdapter.getmType());
                if (assetAdapter.getmType() == DetailAssetRecycleViewAdapter.VIDEO_TYPE) {
                    return;
                }
                if (mModel == null) {
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString(MOVIE_ITEM, String.valueOf(mModel.getmId()));
                mFetchType = FETCH_TRAILERS;
                getSupportLoaderManager().restartLoader(LOADER_CALLBACK_ID, bundle, DetailActivity.this).forceLoad();
            }
        });

        mShowReviewsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mAssetLabel.setVisibility(View.VISIBLE);
                mAssetLabel.setText(getString(R.string.reviews_label));
                if (assetAdapter.getmType() == DetailAssetRecycleViewAdapter.REVIEW_TYPE) {
                    return;
                }
                if (mModel == null) {
                    return;
                }
                Bundle bundle = new Bundle();
                bundle.putString(MOVIE_ITEM, String.valueOf(mModel.getmId()));
                mFetchType = FETCH_REVIEWS;
                getSupportLoaderManager().restartLoader(LOADER_CALLBACK_ID, bundle, DetailActivity.this).forceLoad();
            }
        });

        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                if (mModel != null) {
                    ContentValues values = new ContentValues();
                    values.put(MovieContract.MovieEntry._ID, mModel.getmId());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_TITLE, mModel.getmTitle());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_POSTER, mModel.getmImageUrl());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_OVERVIEW, mModel.getmOverview());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_VOTE_AVERAGE, mModel.getmVoteAverage());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_RELEASE_DATE, mModel.getmReleaseDate());
                    values.put(MovieContract.MovieEntry.COLUMN_MOVIE_LENGTH, mModel.getmLength());
                    resolver.insert(MovieContract.MovieEntry.CONTENT_URI, values);
                } else {
                    likeButton.setLiked(false);
                }
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                if (mModel != null) {
                    resolver.delete(mUri, null, null);
                } else {
                    likeButton.setLiked(true);
                }
            }
        });

    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (assetAdapter.getItemCount() > 0) {
            outState.putParcelableArrayList(ASSETS, (ArrayList<? extends Parcelable>) assetAdapter.getMovieAssets());
            outState.putInt(REQUEST_TYPE, assetAdapter.getmType());
        }
    }

    private void populateUI(Movie model) {
        movieTitleTextView.setText(model.getmTitle());
        movieThumbnailImageView.setContentDescription(model.getmTitle());
        NetworkUtils.loadImage(this, model.getmImageUrl(), movieThumbnailImageView);
        overviewTextView.setText(model.getmOverview());
        String rating = model.getmVoteAverage() + "/10";
        userRatingsTextView.setText(rating);
        releaseDateTextView.setText(model.getmReleaseDate());
        String runtime = model.getmLength() + " minutes";
        lengthTextView.setText(runtime);
    }

    @NonNull
    @Override
    public Loader<String[]> onCreateLoader(int id, @Nullable final Bundle args) {
        return new AsyncTaskLoader<String[]>(this) {
            private String[] result;

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                if (result != null) {
                    deliverResult(result);
                }
            }

            @Nullable
            @Override
            public String[] loadInBackground() {
                String[] jsonResponse = new String[2];
                String modelId = args.getString(MOVIE_ITEM);
                try {
                    jsonResponse[0] = NetworkUtils.getMovieDbResponse(getContext(), modelId, null);
                    if (! TextUtils.isEmpty(mFetchType)) {
                        switch (mFetchType) {
                            case FETCH_TRAILERS:
                                Log.v(DetailActivity.class.getSimpleName(), "Fetching Trailers --------");
                                mFetchType = FETCH_TRAILERS;
                                jsonResponse[1] = NetworkUtils.getAssetsOfMovie(getContext(), mFetchType, modelId);
                                break;
                            case FETCH_REVIEWS:
                                mFetchType = FETCH_REVIEWS;
                                jsonResponse[1] = NetworkUtils.getAssetsOfMovie(getContext(), mFetchType, modelId);
                                break;
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return jsonResponse;
            }

            @Override
            public void deliverResult(@Nullable String[] data) {
                result = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull android.support.v4.content.Loader<String[]> loader, String[] result) {
        try {
            if (result != null) {
                mModel = JsonUtils.convertJsonToMovie(result[0]);
                populateUI(mModel);
                if (mFetchType != null) {
                    switch (mFetchType) {
                        case FETCH_TRAILERS:
                            Log.v(DetailActivity.class.getSimpleName(), "Converting Trailers -------------");
                            List<Video> videos = JsonUtils.getVideoListFromJson(result[1]);
                            assetAdapter.swapMovieAsset(videos, DetailAssetRecycleViewAdapter.VIDEO_TYPE);
                            break;
                        case FETCH_REVIEWS:
                            List<Review> reviews = JsonUtils.getReviewListFromJson(result[1]);
                            assetAdapter.swapMovieAsset(reviews, DetailAssetRecycleViewAdapter.REVIEW_TYPE);
                            break;
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onLoaderReset(@NonNull android.support.v4.content.Loader<String[]> loader) {

    }

}
