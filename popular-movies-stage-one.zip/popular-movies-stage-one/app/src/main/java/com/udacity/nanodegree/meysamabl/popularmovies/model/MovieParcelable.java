package com.udacity.nanodegree.meysamabl.popularmovies.model;

import android.os.Parcel;
import android.os.Parcelable;

public class MovieParcelable implements Parcelable {

    private int mId;
    private String mTitle;
    private String mImageUrl;
    private String mOverview;
    private double mVoteAverage;
    private String mReleaseDate;

    public MovieParcelable(int id, String title, String imageUrl,
                           String overview, double voteAverage, String mReleaseDate) {
        this.mId = id;
        this.mTitle = title;
        this.mImageUrl = imageUrl;
        this.mOverview = overview;
        this.mVoteAverage = voteAverage;
        this.mReleaseDate = mReleaseDate;
    }

    public String getmImageUrl() {
        return mImageUrl;
    }

    public String getmTitle() {
        return mTitle;
    }

    public String getmOverview() {
        return mOverview;
    }

    public double getmVoteAverage() {
        return mVoteAverage;
    }

    public String getmReleaseDate() {
        return mReleaseDate;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.mId);
        dest.writeString(this.mTitle);
        dest.writeString(this.mImageUrl);
        dest.writeString(this.mOverview);
        dest.writeDouble(this.mVoteAverage);
        dest.writeString(this.mReleaseDate);
    }

    protected MovieParcelable(Parcel in) {
        this.mId = in.readInt();
        this.mTitle = in.readString();
        this.mImageUrl = in.readString();
        this.mOverview = in.readString();
        this.mVoteAverage = in.readDouble();
        this.mReleaseDate = in.readString();
    }

    public static final Parcelable.Creator<MovieParcelable> CREATOR = new Parcelable.Creator<MovieParcelable>() {
        @Override
        public MovieParcelable createFromParcel(Parcel source) {
            return new MovieParcelable(source);
        }

        @Override
        public MovieParcelable[] newArray(int size) {
            return new MovieParcelable[size];
        }
    };
}
