package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.*;
import butterknife.BindView;
import butterknife.ButterKnife;
import com.udacity.nanodegree.meysamabl.popularmovies.db.MovieContract;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Movie;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.JsonUtils;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<List<Movie>> {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int GRID_NUMBER_OF_COLUMNS = 2;
    private static final String SORT_BY_KEY = "sort_by_key";
    private static final String SORT_BY_POPULAR_MOVIES = "popular";
    private static final String SORT_BY_TOP_RATED_MOVIES = "top_rated";
    private static final String FETCH_FAVORITE_MOVIES = "fetch_favorite_movies";
    private static final int LOADER_CALLBACK_ID = 23;
    private MovieRecyclerViewAdapter mAdapter;
    @BindView(R.id.pb_loading_indicator)
    ProgressBar mProgressBar;
    @BindView(R.id.movie_recycle_view)
    RecyclerView mRecyclerView;
    @BindView(R.id.error_message)
    TextView mErrorMessageTextView;
    @BindView(R.id.sort_by_drop_down_list)
    Spinner mSortBySpinner;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        RecyclerView.LayoutManager layoutManager = new GridLayoutManager(this, GRID_NUMBER_OF_COLUMNS);
        mAdapter = new MovieRecyclerViewAdapter(this);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mRecyclerView.setHasFixedSize(true);
        ArrayAdapter<CharSequence> mSortByAdapter = ArrayAdapter.createFromResource(
                this,
                R.array.sort_by,
                android.R.layout.simple_spinner_item
        );
        // Specify the layout to use when the list of choices appears
        mSortByAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        mSortBySpinner.setAdapter(mSortByAdapter);
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        final SharedPreferences.Editor editor = sharedPreferences.edit();
        final Bundle bundle = new Bundle();
        mSortBySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                String itemSelected = adapterView.getSelectedItem().toString();
                if (itemSelected.equals(getString(R.string.sort_popular))) {
                    bundle.putString(SORT_BY_KEY, SORT_BY_POPULAR_MOVIES);
                } else if (itemSelected.equals(getString(R.string.sort_top_rated))) {
                    bundle.putString(SORT_BY_KEY, SORT_BY_TOP_RATED_MOVIES);
                } else if (itemSelected.equals(getString(R.string.favorites))) {
                    bundle.putString(SORT_BY_KEY, FETCH_FAVORITE_MOVIES);
                }
                editor.putInt(SORT_BY_KEY, i).apply();
                getSupportLoaderManager().restartLoader(LOADER_CALLBACK_ID, bundle, MainActivity.this);
            }

            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        int position = sharedPreferences.getInt(SORT_BY_KEY, -1);
        mSortBySpinner.setSelection(position);
    }

    private Cursor getAllFavoriteMovies() {
        return getContentResolver().query(
                MovieContract.MovieEntry.CONTENT_URI,
                null,
                null,
                null,
                MovieContract.MovieEntry.COLUMN_MOVIE_TITLE
        );
    }

    @NonNull
    @Override
    public Loader<List<Movie>> onCreateLoader(int i, @Nullable final Bundle bundle) {
        return new AsyncTaskLoader<List<Movie>>(this) {

            private List<Movie> mMovies;

            @Override
            protected void onStartLoading() {
                super.onStartLoading();
                if (mMovies != null) {
                    deliverResult(mMovies);
                } else {
                    if (bundle == null) {
                        return;
                    }
                    mProgressBar.setVisibility(View.VISIBLE);
                    mRecyclerView.setVisibility(View.INVISIBLE);
                    mErrorMessageTextView.setVisibility(View.INVISIBLE);
                    forceLoad();
                }
            }

            @Nullable
            @Override
            public List<Movie> loadInBackground() {
                Log.v(TAG, "Calling loading in background ----------------");
                List<Movie> movies = null;
                try {
                    String response;
                    String sortBy = bundle.getString(SORT_BY_KEY);
                    if (!TextUtils.isEmpty(sortBy) && !sortBy.equals(FETCH_FAVORITE_MOVIES)) {
                        response = NetworkUtils.getMovieDbResponse(
                                MainActivity.this,
                                sortBy,
                                String.valueOf(1)
                        );
                        movies = JsonUtils.getListOfMoviesFromJsonResponse(response);
                    } else {
                        Cursor cursor = null;
                        try {
                            cursor = getAllFavoriteMovies();
                            movies = new ArrayList<>(cursor.getCount());
                            Movie movie;
                            String title, imageUrl, overview, releaseDate;
                            int id;
                            double voteAverage;
                            int colIdIndex = cursor.getColumnIndex(MovieContract.MovieEntry._ID);
                            int colTitleIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_TITLE);
                            int colImageUrlIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_POSTER);
                            int colVoteIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_VOTE_AVERAGE);
                            int colOverviewIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_OVERVIEW);
                            int colReleaseDateIndex = cursor.getColumnIndex(MovieContract.MovieEntry.COLUMN_MOVIE_RELEASE_DATE);
                            while (cursor.moveToNext()) {
                                id = cursor.getInt(colIdIndex);
                                title = cursor.getString(colTitleIndex);
                                imageUrl = cursor.getString(colImageUrlIndex);
                                overview = cursor.getString(colOverviewIndex);
                                voteAverage = cursor.getLong(colVoteIndex);
                                releaseDate = cursor.getString(colReleaseDateIndex);
                                movie = new Movie(
                                        id,
                                        title,
                                        imageUrl,
                                        overview,
                                        voteAverage,
                                        releaseDate
                                );
                                movies.add(movie);
                            }
                        } finally {
                            cursor.close();
                        }
                    }
                } catch (Exception ex) {
                    return null;
                }
                return movies;
            }

            @Override
            public void deliverResult(@Nullable List<Movie> data) {
                mMovies = data;
                super.deliverResult(data);
            }
        };
    }

    @Override
    public void onLoadFinished(@NonNull Loader<List<Movie>> loader, List<Movie> movies) {
        mProgressBar.setVisibility(View.INVISIBLE);
        if (movies != null) {
            mAdapter.setMovies(movies);
            mErrorMessageTextView.setVisibility(View.INVISIBLE);
            mRecyclerView.setVisibility(View.VISIBLE);
        } else {
            mAdapter.setMovies(null);
            mErrorMessageTextView.setVisibility(View.VISIBLE);
            mRecyclerView.setVisibility(View.INVISIBLE);
        }
    }

    @Override
    public void onLoaderReset(@NonNull Loader<List<Movie>> loader) {

    }
}
