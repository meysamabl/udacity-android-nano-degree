package com.udacity.nanodegree.meysamabl.popularmovies.model;

import android.os.Parcelable;

public interface MovieAsset extends Parcelable {
}
