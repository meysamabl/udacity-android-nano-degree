package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.Intent;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import com.udacity.nanodegree.meysamabl.popularmovies.model.MovieAsset;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Review;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Video;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;

import java.util.List;

public class DetailAssetRecycleViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<? extends MovieAsset> movieAssets;
    private int mType = -1;
    static final int VIDEO_TYPE = 0;
    static final int REVIEW_TYPE = 1;

    DetailAssetRecycleViewAdapter() {
    }

    void swapMovieAsset(List<? extends MovieAsset> movieAssets, int type) {
        this.movieAssets = movieAssets;
        this.mType = type;
        notifyDataSetChanged();
    }

    public int getmType() {
        return mType;
    }

    public List<? extends MovieAsset> getMovieAssets() {
        return movieAssets;
    }

    @Override
    public int getItemViewType(int position) {
        return mType;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (mType == VIDEO_TYPE) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.video_item, parent, false);
            return new VideoViewHolder(view);
        } else if (mType == REVIEW_TYPE) {
            View view = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.review_item, parent, false);
            return new ReviewViewHolder(view);
        } else {
            throw new IllegalArgumentException("Unsupported view type");
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof DetailAssetRecycleViewAdapter.ReviewViewHolder) {
            DetailAssetRecycleViewAdapter.ReviewViewHolder viewHolder = (DetailAssetRecycleViewAdapter.ReviewViewHolder) holder;
            viewHolder.bind(position);
        } else if (holder instanceof DetailAssetRecycleViewAdapter.VideoViewHolder) {
            DetailAssetRecycleViewAdapter.VideoViewHolder viewHolder = (DetailAssetRecycleViewAdapter.VideoViewHolder) holder;
            viewHolder.bind(position);
        }
    }

    @Override
    public int getItemCount() {
        return movieAssets == null ? 0 : movieAssets.size();
    }

    public class ReviewViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView authorTextView;
        private TextView contentTextView;

        ReviewViewHolder(View itemView) {
            super(itemView);
            authorTextView = itemView.findViewById(R.id.author_tv);
            contentTextView = itemView.findViewById(R.id.content_tv);
            itemView.setOnClickListener(this);
        }

        void bind(int position) {
            MovieAsset asset = movieAssets.get(position);
            if (asset instanceof Review) {
                Review review = (Review) asset;
                authorTextView.setText(review.getmAuthor());
                contentTextView.setText(review.getmContent());
            }
        }

        @Override
        public void onClick(View v) {
            MovieAsset asset = movieAssets.get(getAdapterPosition());
            if (asset instanceof Review) {
                Review model = (Review) asset;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(model.getmUrl()));
                if (intent.resolveActivity(v.getContext().getPackageManager()) != null) {
                    v.getContext().startActivity(intent);
                }
            }
        }
    }


    public class VideoViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView trailerNameView;

        VideoViewHolder(View itemView) {
            super(itemView);
            trailerNameView = itemView.findViewById(R.id.video_name);
            itemView.setOnClickListener(this);
        }

        void bind(int position) {
            MovieAsset asset = movieAssets.get(position);
            if (asset instanceof Video) {
                Video video = (Video) asset;
                trailerNameView.setText(video.getName());
            }
        }

        @Override
        public void onClick(View v) {
            MovieAsset asset = movieAssets.get(getAdapterPosition());
            if (asset instanceof Video) {
                Video model = (Video) asset;
                NetworkUtils.watchYoutubeVideo(v.getContext(), model.getKey());
            }
        }
    }
}
