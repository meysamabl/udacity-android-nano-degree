package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import com.udacity.nanodegree.meysamabl.popularmovies.model.Movie;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;

import java.util.List;

public class MovieRecyclerViewAdapter extends RecyclerView.Adapter<MovieRecyclerViewAdapter.MovieViewHolder> {

    private List<Movie> movies;
    private final Context mContext;

    public MovieRecyclerViewAdapter(Context context) {
        this.mContext = context;
    }

    public void setMovies(List<Movie> movies) {
        this.movies = movies;
        notifyDataSetChanged();
    }

    public List<Movie> getMovies() {
        return movies;
    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.list_item, viewGroup, false);
        MovieViewHolder movieViewHolder = new MovieViewHolder(view);
        return movieViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder movieViewHolder, int i) {
        movieViewHolder.bind(mContext, i);
    }

    @Override
    public int getItemCount() {
        return movies == null ? 0 : movies.size();
    }

    class MovieViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final ImageView mPosterImageView;

        MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            mPosterImageView = itemView.findViewById(R.id.movie_image_view);
            itemView.setOnClickListener(this);
        }

        void bind(Context context, int i) {
            Movie movie = movies.get(i);
            NetworkUtils.loadImage(context, movie.getmImageUrl(), mPosterImageView);
            mPosterImageView.setContentDescription(movie.getmTitle());
        }

        @Override
        public void onClick(View v) {
            Movie model = movies.get(getAdapterPosition());
            Intent details = new Intent(v.getContext(), DetailActivity.class);
            details.putExtra(DetailActivity.MOVIE_ITEM, model.getmId());
            v.getContext().startActivity(details);
        }
    }
}

