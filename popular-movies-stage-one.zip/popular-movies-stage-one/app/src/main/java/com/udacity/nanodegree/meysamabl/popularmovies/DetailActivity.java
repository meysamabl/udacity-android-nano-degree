package com.udacity.nanodegree.meysamabl.popularmovies;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;
import com.udacity.nanodegree.meysamabl.popularmovies.model.MovieParcelable;
import com.udacity.nanodegree.meysamabl.popularmovies.utilities.NetworkUtils;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        ImageView movieThumbnailImageView = findViewById(R.id.movie_thumbnail_iv);
        TextView movieTitleTextView = findViewById(R.id.detail_title_tv);
        TextView overviewTextView = findViewById(R.id.detail_overview_tv);
        TextView userRatingsTextView = findViewById(R.id.detail_ratings_tv);
        TextView releaseDateTextView = findViewById(R.id.detail_release_date_tv);

        Intent intent = getIntent();
        if (intent.hasExtra(MainActivity.MOVIE_PARCEL)) {
            MovieParcelable model = intent.getParcelableExtra(MainActivity.MOVIE_PARCEL);
            movieTitleTextView.setText(model.getmTitle());
            movieThumbnailImageView.setContentDescription(model.getmTitle());
            NetworkUtils.loadImage(this, model.getmImageUrl(), movieThumbnailImageView);
            overviewTextView.setText(model.getmOverview());
            userRatingsTextView.setText(String.valueOf(model.getmVoteAverage()));
            releaseDateTextView.setText(model.getmReleaseDate());
        }
    }
}
