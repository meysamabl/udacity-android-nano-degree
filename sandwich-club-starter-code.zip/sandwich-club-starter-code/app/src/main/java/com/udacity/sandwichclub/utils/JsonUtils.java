package com.udacity.sandwichclub.utils;

import com.udacity.sandwichclub.model.Sandwich;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        try {
            JSONObject sandwichObj = new JSONObject(json);
            JSONObject nameObject = sandwichObj.getJSONObject("name");
            String mainName = nameObject.getString("mainName");
            List<String> alsoKnownAs = new ArrayList<>();
            JSONArray jArray = nameObject.getJSONArray("alsoKnownAs");
            if (jArray != null) {
                for (int i = 0; i < jArray.length(); i++) {
                    alsoKnownAs.add(jArray.getString(i));
                }
            }
            String placeOfOrigin = sandwichObj.getString("placeOfOrigin");
            String description = sandwichObj.getString("description");
            String image = sandwichObj.getString("image");
            List<String> ingredients = new ArrayList<>();
            jArray = sandwichObj.getJSONArray("ingredients");
            if (jArray != null) {
                for (int i = 0; i < jArray.length(); i++) {
                    ingredients.add(jArray.getString(i));
                }
            }
            return new Sandwich(
                    mainName,
                    alsoKnownAs,
                    placeOfOrigin,
                    description,
                    image,
                    ingredients
            );
        } catch (JSONException e) {
            e.printStackTrace();
            return null;
        }
    }
}
